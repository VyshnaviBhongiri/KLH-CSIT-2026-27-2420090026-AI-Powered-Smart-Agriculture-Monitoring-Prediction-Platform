from pathlib import Path
import sys, subprocess
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'src'/'ai-service'/'dataset'; OUT.mkdir(parents=True,exist_ok=True)
try:
 from datasets import load_dataset
except ImportError:
 subprocess.check_call([sys.executable,'-m','pip','install','datasets>=3.0.0'])
 from datasets import load_dataset
print('Downloading PlantVillage starter subset...')
ds=load_dataset('mohanty/PlantVillage',split='train')
wanted={'Potato___healthy':300,'Potato___Early_blight':300,'Potato___Late_blight':300,'Tomato___healthy':300}
counts={k:0 for k in wanted}
for item in ds:
 label=str(item.get('label_name') or '')
 if label not in wanted or counts[label]>=wanted[label]: continue
 d=OUT/label; d.mkdir(exist_ok=True); item['image'].save(d/f'{label}_{counts[label]:04d}.jpg'); counts[label]+=1
 if all(counts[k]>=wanted[k] for k in wanted): break
print(counts)
if not any(counts.values()): raise SystemExit('No images exported. Check internet/dataset schema.')
