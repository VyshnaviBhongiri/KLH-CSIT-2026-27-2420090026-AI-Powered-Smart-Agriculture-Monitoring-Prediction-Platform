# AI-Powered Smart Agriculture Monitoring and Crop Disease Prediction Platform

**Engineering Capstone Project – 1 | Review–2**

**B. Vaishnavi – 2420090026**  
**S. Lahari Krishna – 2420090055**  
**Guide:** Ms. G. Lavanya  
**Department:** CSE  
**Academic Year:** 2026–2027

## What this package contains

This is a Docker-first, end-to-end academic implementation covering the modules in the Review-2 presentation:

- Login / registration UI
- Farmer dashboard
- Crop leaf image upload
- AI disease prediction service
- Temperature / humidity / soil moisture / light monitoring
- Crop-health analysis
- Irrigation recommendation
- Fertilizer recommendation
- Disease-management guidance
- Prediction history
- PostgreSQL database
- ML training with MobileNetV2 transfer learning
- MLflow experiment tracking
- Docker Compose
- GitHub Actions CI
- Admin statistics API

## Dataset

The project is prepared for the public **PlantVillage** dataset. PlantVillage contains 54,306 leaf images covering 14 crop species and 26 diseases. The official dataset repository documents an 80/20 train/test split and provides a Hugging Face loading route. The complete dataset is intentionally NOT embedded in this ZIP because it is roughly 828 MiB. Instead, the included `setup_dataset.bat` downloads the real dataset and prepares a four-class starter dataset automatically. 

### Starter classes used by this implementation

- `Potato___healthy`
- `Potato___Early_blight`
- `Potato___Late_blight`
- `Tomato___healthy`

You can expand to more classes later by editing `src/ai-service/prepare_dataset.py`.

## IMPORTANT about results

Until you train the model, the AI service uses a clearly labelled `demo_fallback`. Do NOT present demo output as model accuracy. After training, the service switches to `trained_model` automatically.

---

# A. Fastest way to run the whole project

### Prerequisites

- Docker Desktop installed and running
- Git installed
- Windows 10/11
- At least 8 GB RAM recommended
- Internet connection for the first dataset download

### 1. Open Command Prompt in the project folder

```cmd
cd C:\Users\vaish\Downloads\AI-Smart-Agriculture-Complete
```

### 2. Start the complete application

```cmd
docker compose up --build -d
```

This starts:

```text
PostgreSQL  -> localhost:5432
AI Service  -> localhost:8001
FastAPI     -> localhost:8000
React       -> localhost:5173
```

### 3. Open the application

```text
http://localhost:5173
```

### 4. Login for the Review-2 prototype

Use any non-empty username and password.

### 5. API documentation

```text
http://localhost:8000/docs
```

AI service documentation:

```text
http://localhost:8001/docs
```

---

# B. Download the real dataset

Run this AFTER Docker is working:

```cmd
setup_dataset.bat
```

It will create:

```text
src\ai-service\dataset\
    Potato___healthy\
    Potato___Early_blight\
    Potato___Late_blight\
    Tomato___healthy\
```

The script downloads from the PlantVillage dataset through Hugging Face and keeps a configurable number of images per class so training is practical on a normal laptop.

Default: **300 images per class**.

To use more images, open `src\ai-service\prepare_dataset.py` and change `MAX_PER_CLASS`.

---

# C. Train the real disease model

After the dataset is prepared:

```cmd
train_model.bat
```

The training container will create:

```text
src\ai-service\models\disease_model.keras
```

It also logs the training run to MLflow.

Then restart the AI service:

```cmd
docker compose restart ai-service
```

The prediction response should now report:

```text
model_mode: trained_model
```

---

# D. MLflow

Run:

```cmd
start_mlflow.bat
```

Then open:

```text
http://localhost:5000
```

---

# E. Useful Docker commands

View containers:

```cmd
docker compose ps
```

View logs:

```cmd
docker compose logs -f
```

Backend logs:

```cmd
docker compose logs -f backend
```

AI logs:

```cmd
docker compose logs -f ai-service
```

Stop:

```cmd
docker compose down
```

Stop and delete database volume:

```cmd
docker compose down -v
```

---

# F. Project architecture

```text
                Farmer
                   |
                   v
          React Web Application
                   |
       +-----------+-----------+
       |                       |
       v                       v
  Leaf Image            Environmental Data
       |                Temp / Humidity /
       v                Soil / Light
   FastAPI Backend             |
       |                       |
       +-----------+-----------+
                   v
             AI Service
                   |
                   v
          Disease Prediction
                   |
                   v
          Crop Health Analysis
                   |
                   v
          Recommendation Engine
          /        |         \
   Irrigation  Fertilizer  Disease Mgmt
                   |
                   v
             PostgreSQL
                   |
                   v
        Dashboard / History
```

---

# G. Mandatory project structure

```text
AI-Smart-Agriculture-Complete/
├── README.md
├── docker-compose.yml
├── setup_dataset.bat
├── train_model.bat
├── start_mlflow.bat
├── .gitignore
├── .github/workflows/ci.yml
├── src/
│   ├── frontend/
│   ├── backend/
│   ├── ai-service/
│   └── database/
├── docs/
├── data/
├── results/
└── reports/
```

---

# H. Review-2 screenshots to capture

After running the project, capture:

1. Login screen
2. Dashboard
3. Leaf image upload
4. AI prediction result
5. Environmental monitoring
6. Recommendations
7. Prediction history
8. FastAPI Swagger
9. PostgreSQL database records
10. Training output / MLflow
11. GitHub repository
12. Docker containers

The Review-2 PPT describes the farmer flow as Login → Upload Leaf → AI Prediction → Monitor Environment → Analyze → Recommend → Track.

---

# I. Future integration

- Real IoT sensors
- Automated irrigation hardware
- AWS deployment
- GitHub Actions deployment pipeline
- Production authentication/JWT
- More crop/disease classes
- Continuous model monitoring
- Automatic retraining
- Weather API
- Mobile application

## Current Conditions + Explainable AI

The main analysis flow is:

**Leaf Image + Current Conditions -> AI Disease Prediction -> Explainable Recommendation -> Dashboard**

Before pressing **Analyze Crop**, the farmer enters the current values visible from a phone weather report or available sensor reading:

- Temperature
- Humidity
- Soil moisture
- Light intensity

The recommendation engine combines these values with the image prediction. The result includes both the recommendation and a plain-language explanation of the factors that triggered it.

Example: if soil moisture is 24%, the system can say irrigation is recommended **because soil moisture is low**. If humidity is 86%, the explanation can state that high humidity can favor fungal disease development. These are decision-rule explanations around the model output, not a claim of causal proof.
