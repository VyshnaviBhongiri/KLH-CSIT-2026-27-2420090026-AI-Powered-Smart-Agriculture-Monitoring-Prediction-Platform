PostgreSQL database: smart_agriculture. Tables are created automatically by SQLAlchemy.
