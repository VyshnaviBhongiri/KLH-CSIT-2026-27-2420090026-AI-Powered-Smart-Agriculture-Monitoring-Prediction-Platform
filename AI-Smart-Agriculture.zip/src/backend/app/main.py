from pathlib import Path
from datetime import datetime
import shutil,os,requests
from fastapi import FastAPI,UploadFile,File,Form,Depends,HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from .database import Base,engine,get_db
from .models import User,Prediction
from .recommendations import make_recommendations
Base.metadata.create_all(bind=engine)
app=FastAPI(title='AI Smart Agriculture API',version='1.0.0')
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_credentials=True,allow_methods=['*'],allow_headers=['*'])
UPLOAD=Path('/app/uploads');UPLOAD.mkdir(exist_ok=True)
AI=os.getenv('AI_SERVICE_URL','http://ai-service:8001')
@app.get('/api/health')
def health(): return {'status':'ok','service':'backend'}
@app.post('/api/auth/login')
def login(username:str=Form(...),password:str=Form(...),db:Session=Depends(get_db)):
 if not username.strip() or not password.strip(): raise HTTPException(400,'Username and password required')
 u=db.query(User).filter(User.username==username.strip()).first()
 if not u: u=User(username=username.strip());db.add(u);db.commit();db.refresh(u)
 return {'username':u.username,'role':u.role}
@app.get('/api/environment')
def environment(): return {'temperature':None,'humidity':None,'soil_moisture':None,'light_intensity':None,'source':'waiting for live weather'}

@app.get('/api/weather')
def weather(lat: float, lon: float):
    try:
        params = {
            'latitude': lat, 'longitude': lon,
            'current': 'temperature_2m,relative_humidity_2m,precipitation,rain,cloud_cover,wind_speed_10m,shortwave_radiation',
            'hourly': 'soil_moisture_0_to_10cm',
            'forecast_hours': 1,
            'timezone': 'auto'
        }
        r = requests.get('https://api.open-meteo.com/v1/forecast', params=params, timeout=12)
        r.raise_for_status()
        data = r.json()
        c = data.get('current', {})
        h = data.get('hourly', {})
        soil = (h.get('soil_moisture_0_to_10cm') or [None])[0]
        return {
            'temperature': c.get('temperature_2m'),
            'humidity': c.get('relative_humidity_2m'),
            'precipitation': c.get('precipitation'),
            'rain': c.get('rain'),
            'cloud_cover': c.get('cloud_cover'),
            'wind_speed': c.get('wind_speed_10m'),
            'light_intensity': c.get('shortwave_radiation'),
            'soil_moisture_model': soil,
            'latitude': lat,
            'longitude': lon,
            'timezone': data.get('timezone'),
            'source': 'Open-Meteo live weather/model data'
        }
    except requests.RequestException as e:
        raise HTTPException(503, f'Weather service unavailable: {e}')
@app.post('/api/predict')
async def predict(temperature:float=Form(...),humidity:float=Form(...),soil_moisture:float=Form(...),light_intensity:float=Form(780),image:UploadFile=File(...),username:str=Form('Farmer'),db:Session=Depends(get_db)):
 if not image.content_type or not image.content_type.startswith('image/'): raise HTTPException(400,'Image file required')
 ext=Path(image.filename or 'leaf.jpg').suffix or '.jpg';path=UPLOAD/(datetime.utcnow().strftime('%Y%m%d%H%M%S%f')+ext)
 with path.open('wb') as f: shutil.copyfileobj(image.file,f)
 try:
  with path.open('rb') as f: r=requests.post(AI+'/predict',files={'image':(image.filename or 'leaf.jpg',f,image.content_type)},timeout=180)
  if r.status_code!=200: raise HTTPException(503,r.text)
  a=r.json()
 except requests.RequestException as e: raise HTTPException(503,f'AI service unavailable: {e}')
 disease=a['disease'];conf=float(a['confidence']);
 rec=make_recommendations(disease,temperature,humidity,soil_moisture,light_intensity)
 irrigation=rec['irrigation']; fertilizer=rec['fertilizer']; management=rec['disease_management']
 row=Prediction(username=username,filename=image.filename,disease=disease,confidence=conf,health_status='Healthy' if disease=='Healthy' else 'Needs Attention',temperature=temperature,humidity=humidity,soil_moisture=soil_moisture,light_intensity=light_intensity,irrigation=irrigation,fertilizer=fertilizer,disease_management=management)
 db.add(row);db.commit();db.refresh(row)
 return {'id':row.id,'disease':disease,'confidence':round(conf*100,2),'health_status':row.health_status,'temperature':temperature,'humidity':humidity,'soil_moisture':soil_moisture,'light_intensity':light_intensity,'irrigation':irrigation,'fertilizer':fertilizer,'disease_management':management,'created_at':row.created_at,'model_mode':a.get('model_mode'),'explanation':rec['explanation'],'recommendation_levels':rec['levels']}
@app.get('/api/predictions')
def predictions(db:Session=Depends(get_db)):
 rows=db.query(Prediction).order_by(Prediction.created_at.desc()).limit(100).all();return [{'id':r.id,'disease':r.disease,'confidence':round(r.confidence*100,2),'health_status':r.health_status,'temperature':r.temperature,'humidity':r.humidity,'soil_moisture':r.soil_moisture,'light_intensity':r.light_intensity,'irrigation':r.irrigation,'fertilizer':r.fertilizer,'disease_management':r.disease_management,'created_at':r.created_at} for r in rows]
@app.get('/api/dashboard')
def dashboard(db:Session=Depends(get_db)):
 rows=db.query(Prediction).all();healthy=sum(r.disease=='Healthy' for r in rows);diseased=len(rows)-healthy;return {'total_predictions':len(rows),'healthy':healthy,'diseased':diseased,'alerts':min(diseased,9)}
@app.get('/api/admin/stats')
def admin_stats(db:Session=Depends(get_db)): return {'users':db.query(User).count(),'predictions':db.query(Prediction).count()}
