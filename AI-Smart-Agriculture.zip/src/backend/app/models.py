from datetime import datetime
from sqlalchemy import Column,Integer,Float,String,DateTime,Text
from .database import Base
class User(Base):
 __tablename__='users'; id=Column(Integer,primary_key=True); username=Column(String(100),unique=True,index=True); role=Column(String(30),default='farmer'); created_at=Column(DateTime,default=datetime.utcnow)
class Prediction(Base):
 __tablename__='predictions'
 id=Column(Integer,primary_key=True); username=Column(String(100),default='Farmer'); filename=Column(String(255)); disease=Column(String(120)); confidence=Column(Float); health_status=Column(String(50)); temperature=Column(Float); humidity=Column(Float); soil_moisture=Column(Float); light_intensity=Column(Float); irrigation=Column(String(500)); fertilizer=Column(String(500)); disease_management=Column(Text); created_at=Column(DateTime,default=datetime.utcnow)
