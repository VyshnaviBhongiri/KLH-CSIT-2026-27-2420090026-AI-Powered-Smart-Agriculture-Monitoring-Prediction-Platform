import os
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base,sessionmaker
DATABASE_URL=os.getenv('DATABASE_URL','sqlite:///./smart_agriculture.db')
kwargs={'connect_args':{'check_same_thread':False}} if DATABASE_URL.startswith('sqlite') else {'pool_pre_ping':True}
engine=create_engine(DATABASE_URL,**kwargs)
SessionLocal=sessionmaker(bind=engine,autocommit=False,autoflush=False)
Base=declarative_base()
def get_db():
 db=SessionLocal()
 try: yield db
 finally: db.close()
