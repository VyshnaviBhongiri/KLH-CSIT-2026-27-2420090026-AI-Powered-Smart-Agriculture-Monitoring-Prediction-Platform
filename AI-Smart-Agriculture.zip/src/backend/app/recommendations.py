def make_recommendations(disease, temperature, humidity, soil_moisture, light_intensity=780):
    if soil_moisture < 30:
        irrigation = 'Irrigate soon.'
        irrigation_reason = f'Soil moisture is low at {soil_moisture}%. The crop may be under water stress.'
        irrigation_level = 'High'
    elif soil_moisture < 55:
        irrigation = 'Use moderate irrigation and recheck soil moisture.'
        irrigation_reason = f'Soil moisture is {soil_moisture}%, which is in the moderate range.'
        irrigation_level = 'Medium'
    else:
        irrigation = 'No immediate irrigation.'
        irrigation_reason = f'Soil moisture is adequate at {soil_moisture}%.'
        irrigation_level = 'Low'

    if humidity >= 80:
        humidity_reason = f'Humidity is high at {humidity}%, which can favor fungal disease development.'
    elif humidity <= 40:
        humidity_reason = f'Humidity is relatively low at {humidity}%, so monitor for plant water stress.'
    else:
        humidity_reason = f'Humidity is {humidity}%, within a moderate range.'

    if temperature >= 32:
        temperature_reason = f'Temperature is high at {temperature}C; avoid heavy fertilizer application during heat.'
        fertilizer = 'Avoid heavy fertilizer during high heat; maintain balanced nutrition.'
    elif temperature < 18:
        temperature_reason = f'Temperature is relatively low at {temperature}C; avoid over-irrigation.'
        fertilizer = 'Use balanced fertilizer according to crop stage and soil-test guidance.'
    else:
        temperature_reason = f'Temperature is {temperature}C, a moderate condition for the current rule set.'
        fertilizer = 'Use balanced fertilizer according to crop stage and soil-test guidance.'
    if humidity >= 80:
        fertilizer += ' Avoid excessive nitrogen under high humidity.'

    if disease == 'Healthy':
        management = 'Continue regular monitoring and maintain field hygiene.'
        disease_reason = 'The AI prediction indicates a healthy crop.'
    else:
        management = f'Monitor the detected {disease} closely, remove affected material where practical, improve airflow, avoid excessive overhead irrigation, and consult local agricultural guidance before treatment.'
        disease_reason = f'The AI prediction indicates {disease}; management guidance is focused on containment and monitoring.'

    if light_intensity < 300:
        light_reason = f'Light intensity is low at {light_intensity} lux; check whether the crop is receiving sufficient light.'
    elif light_intensity > 10000:
        light_reason = f'Light intensity is high at {light_intensity} lux; monitor for heat or light stress.'
    else:
        light_reason = f'Light intensity is {light_intensity} lux; no light-specific alert was triggered.'

    return {
        'irrigation': irrigation,
        'fertilizer': fertilizer,
        'disease_management': management,
        'explanation': {
            'irrigation': irrigation_reason,
            'humidity': humidity_reason,
            'temperature': temperature_reason,
            'disease': disease_reason,
            'light': light_reason
        },
        'levels': {'irrigation': irrigation_level}
    }
