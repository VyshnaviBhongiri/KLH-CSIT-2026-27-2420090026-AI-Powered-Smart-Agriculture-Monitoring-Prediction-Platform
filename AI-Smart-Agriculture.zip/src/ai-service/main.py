from pathlib import Path
from fastapi import FastAPI,UploadFile,File,HTTPException
from PIL import Image
import numpy as np
app=FastAPI(title='Smart Agriculture AI Service',version='1.0.0')
MODEL=Path('/app/models/disease_model.keras');CLASSES=['Potato___healthy','Potato___Early_blight','Potato___Late_blight','Tomato___healthy']
def demo(path):
 a=np.asarray(Image.open(path).convert('RGB').resize((128,128)),dtype=np.float32)/255
 g=float(a[:,:,1].mean());r=float(a[:,:,0].mean())
 if g>.48 and g>r*1.15:return 'Healthy',.82
 if r>g*1.18:return 'Early Blight',.76
 return 'Late Blight',.71
def real(path):
 import tensorflow as tf
 m=tf.keras.models.load_model(MODEL);x=np.expand_dims(np.asarray(Image.open(path).convert('RGB').resize((224,224)),dtype=np.float32),0)/255;p=m.predict(x,verbose=0)[0];i=int(np.argmax(p));return CLASSES[i].replace('___',' - ').replace('_',' '),float(p[i])
@app.get('/health')
def health():return {'status':'ok','model_available':MODEL.exists()}
@app.post('/predict')
async def predict(image:UploadFile=File(...)):
 if not image.content_type or not image.content_type.startswith('image/'):raise HTTPException(400,'Image required')
 path=Path('/app/_input.jpg');path.write_bytes(await image.read())
 try:
  if MODEL.exists():d,c=real(path);mode='trained_model'
  else:d,c=demo(path);mode='demo_fallback'
  return {'disease':d,'confidence':c,'model_mode':mode}
 finally:path.unlink(missing_ok=True)
