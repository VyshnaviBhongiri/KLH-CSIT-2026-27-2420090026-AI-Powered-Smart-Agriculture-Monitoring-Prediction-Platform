Download with setup_dataset.bat. The script creates the four starter classes.
