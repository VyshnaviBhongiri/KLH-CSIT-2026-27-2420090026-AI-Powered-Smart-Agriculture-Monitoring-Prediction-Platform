# Downloads the real PlantVillage dataset through Hugging Face and writes a manageable local subset.
from pathlib import Path
from datasets import load_dataset
from PIL import Image
import re

OUT=Path('/app/dataset');MAX_PER_CLASS=300
TARGETS=['Potato___healthy','Potato___Early_blight','Potato___Late_blight','Tomato___healthy']
print('Loading PlantVillage color dataset. First download can be large.')
ds=load_dataset('mohanty/PlantVillage','color',split='train')
counts={x:0 for x in TARGETS}
for row in ds:
 label=ds.features['label'].names[row['label']]
 if label not in TARGETS or counts[label]>=MAX_PER_CLASS: continue
 folder=OUT/label;folder.mkdir(parents=True,exist_ok=True)
 img=row['image'];
 if not isinstance(img,Image.Image): img=Image.fromarray(img)
 img.save(folder/f"{counts[label]:05d}.jpg",quality=92)
 counts[label]+=1
 if all(v>=MAX_PER_CLASS for v in counts.values()): break
print('Prepared:',counts)
