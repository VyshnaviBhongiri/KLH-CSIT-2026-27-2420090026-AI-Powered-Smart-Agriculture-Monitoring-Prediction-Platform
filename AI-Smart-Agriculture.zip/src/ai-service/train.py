from pathlib import Path
import tensorflow as tf
import mlflow
DATA=Path('/app/dataset');OUT=Path('/app/models/disease_model.keras');SIZE=(224,224)
train=tf.keras.utils.image_dataset_from_directory(DATA,validation_split=.2,subset='training',seed=42,image_size=SIZE,batch_size=32)
val=tf.keras.utils.image_dataset_from_directory(DATA,validation_split=.2,subset='validation',seed=42,image_size=SIZE,batch_size=32)
base=tf.keras.applications.MobileNetV2(input_shape=SIZE+(3,),include_top=False,weights='imagenet');base.trainable=False
model=tf.keras.Sequential([tf.keras.layers.Rescaling(1./255),base,tf.keras.layers.GlobalAveragePooling2D(),tf.keras.layers.Dropout(.2),tf.keras.layers.Dense(len(train.class_names),activation='softmax')])
model.compile(optimizer='adam',loss='sparse_categorical_crossentropy',metrics=['accuracy'])
mlflow.set_experiment('smart-agriculture-disease')
with mlflow.start_run():
 h=model.fit(train,validation_data=val,epochs=5);mlflow.log_metric('train_accuracy',float(h.history['accuracy'][-1]));mlflow.log_metric('validation_accuracy',float(h.history['val_accuracy'][-1]))
OUT.parent.mkdir(parents=True,exist_ok=True);model.save(OUT);print('Saved',OUT,'classes',train.class_names)
