@echo off
setlocal
cd /d %~dp0

echo ================================================
echo Smart Agriculture - Train AI Model
echo ================================================

echo Building AI training image...
docker compose build ai-service
if errorlevel 1 goto fail

echo.
echo Training MobileNetV2 model...
docker compose run --rm ai-service python train.py
if errorlevel 1 goto fail

echo.
echo Model training completed.
echo Restarting AI service...
docker compose restart ai-service
pause
exit /b 0

:fail
echo.
echo Training failed. Check the dataset and Docker logs.
pause
exit /b 1
