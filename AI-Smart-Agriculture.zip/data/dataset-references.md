# Dataset Reference
PlantVillage Dataset: https://github.com/spMohanty/PlantVillage-Dataset
Hugging Face configuration: mohanty/PlantVillage, color
The dataset is used for academic disease-classification development. Record the exact dataset version and license information used by the team before final submission.
