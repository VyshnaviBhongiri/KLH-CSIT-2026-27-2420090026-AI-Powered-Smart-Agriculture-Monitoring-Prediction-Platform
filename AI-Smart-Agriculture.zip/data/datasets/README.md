Store project outputs here. Do not claim metrics until they are produced by the real trained model.
