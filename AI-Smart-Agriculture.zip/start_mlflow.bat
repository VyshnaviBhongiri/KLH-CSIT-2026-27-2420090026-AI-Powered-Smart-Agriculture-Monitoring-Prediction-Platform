@echo off
cd /d %~dp0
if not exist mlruns mkdir mlruns

echo Starting MLflow on http://localhost:5000
mlflow ui --host 0.0.0.0 --port 5000 --backend-store-uri ./mlruns
pause
