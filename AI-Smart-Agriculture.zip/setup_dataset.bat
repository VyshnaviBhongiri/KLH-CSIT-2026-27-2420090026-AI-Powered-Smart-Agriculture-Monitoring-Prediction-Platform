@echo off
cd /d "%~dp0"
python tools\download_dataset.py
pause
