# User Stories
- As a farmer, I want to upload a leaf image so I can receive a disease prediction.
- As a farmer, I want environmental information so I can monitor crop conditions.
- As a farmer, I want recommendations so I can make better irrigation and disease-management decisions.
- As a farmer, I want prediction history so I can track crop health.
