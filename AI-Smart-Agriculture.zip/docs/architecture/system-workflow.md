# System Workflow
Login → Dashboard → Leaf Image + Environment → FastAPI → AI Service → Prediction → Recommendations → PostgreSQL → History/Dashboard
